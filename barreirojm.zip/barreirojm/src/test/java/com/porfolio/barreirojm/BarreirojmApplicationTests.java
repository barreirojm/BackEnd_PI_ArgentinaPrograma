package com.porfolio.barreirojm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BarreirojmApplicationTests {

	@Test
	void contextLoads() {
	}

}
